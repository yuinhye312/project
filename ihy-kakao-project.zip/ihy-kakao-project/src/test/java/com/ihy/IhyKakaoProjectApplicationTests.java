package com.ihy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IhyKakaoProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
