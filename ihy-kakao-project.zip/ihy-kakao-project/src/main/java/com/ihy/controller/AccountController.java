package com.ihy.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ihy.store.model.Account;
import com.ihy.store.service.AccountService;

@RestController
@RequestMapping("/account/")
public class AccountController {

	@Resource(name = "accountServiceImpl")
	private AccountService accountService;
	
	
	@RequestMapping(value = "add", method = RequestMethod.POST)
	public Account add(@RequestBody Account account) {
		
		Account addAcct = null;
		
		try {
			addAcct = accountService.add(account);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return addAcct;
	}
	
	@RequestMapping(value = "list", method = RequestMethod.GET)
	public List<Account> getAll() {
		try {
			return accountService.getAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
}
