package com.ihy.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ihy.store.model.balance.AvgBalByAges;
import com.ihy.store.model.balance.BalByUser;
import com.ihy.store.model.balance.UserAccount;
import com.ihy.store.service.BalanceService;

@RestController
@RequestMapping("/balance/")
public class BalanceController {

	@Resource(name = "balServiceImpl")
	private BalanceService balService;
	
	@RequestMapping(value = "user/account", method = RequestMethod.GET)
	public List<BalByUser> accountBalsByUser(int userId) {
		try {
			return balService.accountBalsByUser(userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	@RequestMapping(value = "average/ages", method = RequestMethod.GET)
	public List<AvgBalByAges> accountAvgBalByAges() {
		try {
			return balService.accountAvgBalByAges();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	@RequestMapping(value = "year", method = RequestMethod.GET)
	public Integer totalBalByYears(String year) {
		try {
			return balService.totalBalByYears(year);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	@RequestMapping(value = "terms", method = RequestMethod.GET)
	public List<UserAccount> balByTerm(String strDt, String endDt){
		try {
			return balService.balByTerm(strDt, endDt);
					
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
}
