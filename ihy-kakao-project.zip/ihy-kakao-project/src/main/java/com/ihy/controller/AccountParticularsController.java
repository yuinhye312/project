package com.ihy.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ihy.store.model.AccountParticulars;
import com.ihy.store.service.AccountParticularsService;

@RestController
@RequestMapping("/accountptcl/")
public class AccountParticularsController {

	@Resource(name = "accountParticularsServiceImpl")
	private AccountParticularsService acctPtclService;
	
	
	@RequestMapping(value = "add", method = RequestMethod.POST)
	public AccountParticulars add(@RequestBody AccountParticulars acctPtcl) {
		
		AccountParticulars addAcctPtcl = null;
		
		try {
			addAcctPtcl = acctPtclService.add(acctPtcl);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return addAcctPtcl;
	}
	
	@RequestMapping(value = "list", method = RequestMethod.GET)
	public List<AccountParticulars> getAll() {
		try {
			return acctPtclService.getAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
}
