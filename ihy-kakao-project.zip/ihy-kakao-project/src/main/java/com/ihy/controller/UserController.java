package com.ihy.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ihy.store.model.User;
import com.ihy.store.service.UserService;

@RestController
@RequestMapping("/user/")
public class UserController {

	@Resource(name = "userServiceImpl")
	private UserService userService;
	
	
	@RequestMapping(value = "add", method = RequestMethod.POST)
	public User add(@RequestBody User user) {
		
		User addUsr = null;
		
		try {
			addUsr = userService.add(user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return addUsr;
	}
	
	@RequestMapping(value = "list", method = RequestMethod.GET)
	public List<User> getAll() {
		try {
			return userService.getAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
}
