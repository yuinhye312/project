package com.ihy.store.model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import com.ihy.store.model.pk.AccountMasterPk;


@Entity
@Table(name = "account")
public class Account {
	
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="user_id", insertable = false, updatable = false)
	private int userId;
	@Column(name="acct_no", insertable = false, updatable = false)
	private String acctNo;
	
	@EmbeddedId
	private AccountMasterPk accountMasterPk;
	
	public int getUserId() {
		return userId;
	}
	
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public String getAcctNo() {
		return acctNo;
	}
	
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}
	
}