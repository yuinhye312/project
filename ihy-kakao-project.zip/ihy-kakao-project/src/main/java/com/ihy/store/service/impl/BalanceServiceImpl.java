package com.ihy.store.service.impl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ihy.store.model.Account;
import com.ihy.store.model.Ages;
import com.ihy.store.model.User;
import com.ihy.store.model.balance.AvgBalByAges;
import com.ihy.store.model.balance.BalByUser;
import com.ihy.store.model.balance.UserAccount;
import com.ihy.store.repository.AccountParticularsRepository;
import com.ihy.store.repository.AccountRepository;
import com.ihy.store.repository.UserRepository;
import com.ihy.store.service.BalanceService;

@Service(value = "balServiceImpl")
public class BalanceServiceImpl implements BalanceService {

	@Autowired
	private AccountRepository accountRepo;
	@Autowired
	private AccountParticularsRepository acctPtclRepo;
	@Autowired
	private UserRepository usrRepo;
	
	@Override
	public List<BalByUser> accountBalsByUser(int userId) throws Exception {
		
		List<BalByUser> result = new ArrayList<BalByUser>();
		List<Account> accounts = accountRepo.findAllByUserId(userId);
		for (Account account : accounts) {
			BalByUser balByUsr = new BalByUser();
			
			int inComeBal = 0;
			int outComeBal = 0;
			
			inComeBal = acctPtclRepo.totalAmt(account.getAcctNo(), "Y");
			outComeBal = acctPtclRepo.totalAmt(account.getAcctNo(), "N"); 
			
			int bal = inComeBal - outComeBal;
			
			balByUsr.setAcctNo(account.getAcctNo());
			balByUsr.setBalance(bal);
			
			result.add(balByUsr);
		}
		
		return result;
	}

	@Override
	public List<AvgBalByAges> accountAvgBalByAges() throws Exception {
		
		List<AvgBalByAges> result = new ArrayList<AvgBalByAges>();
		
		AvgBalByAges agesBal;
		
		List<Ages> ages = new ArrayList<Ages>();
		ages.add(new Ages(10, 19));
		ages.add(new Ages(20, 29));
		ages.add(new Ages(30, 39));
		ages.add(new Ages(40, 49));
		ages.add(new Ages(50, 59));
		ages.add(new Ages(60, 69));
		ages.add(new Ages(70, 79));
		
		for (Ages age : ages) {
			agesBal = new AvgBalByAges();
			
			List<User> users = usrRepo.findAllByAgeBetween(age.getStart(), age.getEnd());
			int usrsTotalBal = 0;
			
			for (User user : users) {
				List<BalByUser> userBals = accountBalsByUser(user.getUserId());
				for (BalByUser bal : userBals) {
					usrsTotalBal += bal.getBalance();
				}
			}
			
			agesBal.setAges(age.getStart() + "");
			agesBal.setAvgBal(usrsTotalBal / users.size());

			result.add(agesBal);
		}
		
		return result;
	}

	@Override
	public Integer totalBalByYears(String year) throws Exception {
		
		int inComeBal = acctPtclRepo.totalAmtByYear("Y", year);
		int outComeBal = acctPtclRepo.totalAmtByYear("N", year);
		
		return inComeBal - outComeBal;
	}

	@Override
	public List<UserAccount> balByTerm(String strDt, String endDt) throws Exception {
		List<Map<String, Object>> queryRst = acctPtclRepo.totalAmtTerm(strDt, endDt);
		List<UserAccount> result = new ArrayList<UserAccount>();
		UserAccount userAcct;
		
		for (Map<String, Object> map : queryRst) {
			userAcct = new UserAccount();
			userAcct.setUserId((int) map.get("userId"));
			userAcct.setName((String) map.get("name"));
			userAcct.setBalance((BigInteger) map.get("balance"));
			
			result.add(userAcct);
		}
		
		return result;
	}

}
