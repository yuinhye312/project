package com.ihy.store.model.balance;

public class BalByUser {
	private String acctNo;
	private Integer balance;
	
	public String getAcctNo() {
		return acctNo;
	}
	
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}
	
	public Integer getBalance() {
		return balance;
	}
	
	public void setBalance(Integer balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "AccountBalance [acctNo=" + acctNo + ", balance=" + balance + "]";
	}
}
