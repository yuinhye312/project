package com.ihy.store.service;

import java.util.List;

import com.ihy.store.model.Account;

public interface AccountService {
	public Account add(Account account) throws Exception;
	public List<Account> getAll() throws Exception;
}
