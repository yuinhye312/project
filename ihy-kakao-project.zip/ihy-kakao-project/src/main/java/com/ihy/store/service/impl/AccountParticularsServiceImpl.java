package com.ihy.store.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ihy.store.model.AccountParticulars;
import com.ihy.store.repository.AccountParticularsRepository;
import com.ihy.store.service.AccountParticularsService;

@Service(value = "accountParticularsServiceImpl")
public class AccountParticularsServiceImpl implements AccountParticularsService {

	@Autowired
	private AccountParticularsRepository acctPtclRepo;
	
	@Override
	public AccountParticulars add(AccountParticulars acctPtcl) throws Exception {
		return acctPtclRepo.save(acctPtcl);
	}

	@Override
	public List<AccountParticulars> getAll() throws Exception {
		return acctPtclRepo.findAll();
	}

}
