package com.ihy.store.model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import com.ihy.store.model.pk.AccountPtclMasterPk;

@Entity
@Table(name = "accountParticulars")
public class AccountParticulars {

	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="acct_no", insertable = false, updatable = false)
	private String acctNo;
	@Column(name="is_income", insertable = false, updatable = false)
	private Boolean isIncome;
	@Column(name="trsc_amt", insertable = false, updatable = false)
	private Integer trscAmt;
	@Column(name="trsc_date", insertable = false, updatable = false)
	private String trscDate;
	
	@EmbeddedId
	private AccountPtclMasterPk accountPtclMasterPk;
	
	public String getAcctNo() {
		return acctNo;
	}
	
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}
	
	public Boolean getIsIncome() {
		return isIncome;
	}
	
	public void setIsIncome(Boolean isIncome) {
		this.isIncome = isIncome;
	}
	
	public Integer getTrscAmt() {
		return trscAmt;
	}
	
	public void setTrscAmt(Integer trscAmt) {
		this.trscAmt = trscAmt;
	}
	
	public String getTrscDate() {
		return trscDate;
	}
	
	public void setTrscDate(String trscDate) {
		this.trscDate = trscDate;
	}
	
	
}
