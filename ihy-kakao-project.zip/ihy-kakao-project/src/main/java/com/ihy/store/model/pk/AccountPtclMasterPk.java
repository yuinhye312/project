package com.ihy.store.model.pk;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class AccountPtclMasterPk implements Serializable{
    private static final long serialVersionUID = 1L;

    @Column(name="acct_no")
    private String acctNo;
	@Column(name="is_income")
	private String isIncome;
	@Column(name="trsc_amt")
	private Integer trscAmt;
	@Column(name="trsc_date")
	private String trscDate;

    public AccountPtclMasterPk(){}

    public AccountPtclMasterPk(String acctNo, String isIncome, Integer trscAmt, String trscDate) {
        this.acctNo = acctNo;
        this.isIncome = isIncome;
        this.trscAmt = trscAmt;
        this.trscDate = trscDate;
    }

    @Override
    public boolean equals(Object obj) {
        if(this == obj) {
            return true;
        }

        if(obj == null || this.getClass() != obj.getClass()) {
            return false;
        }

        AccountPtclMasterPk accountPtclMasterPk = (AccountPtclMasterPk) obj;

        if (this.acctNo.equals(accountPtclMasterPk.acctNo) 
        		&& this.isIncome.equals(accountPtclMasterPk.isIncome)
        		&& this.trscAmt.equals(accountPtclMasterPk.trscAmt)
        		&& this.trscDate.equals(accountPtclMasterPk.trscDate)
        		){
            return true;
        }
        
        return false;
    }

    @Override
    public int hashCode() {
        return Objects.hash(acctNo, isIncome, trscAmt, trscDate);        
    }
}