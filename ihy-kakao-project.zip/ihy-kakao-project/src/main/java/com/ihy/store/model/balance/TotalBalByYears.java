package com.ihy.store.model.balance;

public class TotalBalByYears {

}
