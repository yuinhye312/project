package com.ihy.store.model.pk;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class AccountMasterPk implements Serializable{
    private static final long serialVersionUID = 1L;

    @Column(name="user_id")
    private String userId;
    @Column(name="acct_no")
    private String acctNo;

    public AccountMasterPk(){}

    public AccountMasterPk(String userId, String acctNo) {
        this.userId = userId;
        this.acctNo = acctNo;
    }

    @Override
    public boolean equals(Object obj) {
        if(this == obj) {
            return true;
        }

        if(obj == null || this.getClass() != obj.getClass()) {
            return false;
        }

        AccountMasterPk accountMasterPk = (AccountMasterPk) obj;

        if (this.userId.equals(accountMasterPk.userId) 
        		&& this.acctNo.equals(accountMasterPk.acctNo)) {
            return true;
        }
        
        return false;
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId, acctNo);        
    }
}