package com.ihy.store.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ihy.store.model.AccountParticulars;

@Repository
public interface AccountParticularsRepository extends JpaRepository<AccountParticulars, Integer>{	
	@Query(value =
	        "SELECT "
	           + " NVL(SUM(TRSC_AMT), 0)" 
	           + " FROM ACCOUNT_PARTICULARS"
			   + " WHERE acct_no = :acctNo"
	           +   " AND is_income = :isIncome"
	        , nativeQuery = true
	    )
	Integer totalAmt(@Param("acctNo") String acctNo, @Param("isIncome") String isIncome);

	@Query(value =
	        "SELECT "
	           + " NVL(SUM(TRSC_AMT), 0)" 
	           + " FROM ACCOUNT_PARTICULARS"
			   + " WHERE is_income = :isIncome"
	           + " AND SUBSTR(trsc_date, 1, 4) = :year"
	        , nativeQuery = true
	    )
	Integer totalAmtByYear(@Param("isIncome") String isIncome, @Param("year") String year);
	
	
	@Query(value =
			" SELECT userId, name, income - outcome as balance"
					+ " from"
					+ "(" 
					+ " SELECT"
					+ "       u.user_id as userId,"
					+ "       u.name as name,"
					+ "       NVL(SUM(CASE WHEN p.is_income = 'Y' THEN p.TRSC_AMT END), 0) as income,"
					+ "       NVL(SUM(CASE WHEN p.is_income = 'N' THEN p.TRSC_AMT END), 0) as outcome,"
					+ "   FROM"
					+ "       ACCOUNT_PARTICULARS p, ACCOUNT t, USER u "
					+ "    WHERE"
					+ "       u.user_id = t.user_id   "
					+ "       AND t.acct_no = p.acct_no"   
					+ "       AND p.trsc_date between :strDate and :endDate"
					+ "    GROUP BY u.user_id"
					+ ")"
					+ "order by balance desc"
	        , nativeQuery = true
	    )
	List<Map<String, Object>> totalAmtTerm(@Param("strDate") String strDate
									, @Param("endDate") String endDate);

}


