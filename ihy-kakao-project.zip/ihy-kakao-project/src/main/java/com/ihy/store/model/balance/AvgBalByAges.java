package com.ihy.store.model.balance;

public class AvgBalByAges {
	private String ages;
	private Integer avgBal;
	
	public String getAges() {
		return ages;
	}
	
	public void setAges(String ages) {
		this.ages = ages;
	}
	
	public Integer getAvgBal() {
		return avgBal;
	}
	
	public void setAvgBal(Integer avgBal) {
		this.avgBal = avgBal;
	}
	
	@Override
	public String toString() {
		return "AvgBalByAges [ages=" + ages + ", avgBal=" + avgBal + "]";
	}
}
