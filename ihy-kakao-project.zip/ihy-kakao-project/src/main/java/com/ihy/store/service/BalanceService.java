package com.ihy.store.service;

import java.util.List;

import com.ihy.store.model.balance.AvgBalByAges;
import com.ihy.store.model.balance.BalByUser;
import com.ihy.store.model.balance.UserAccount;

public interface BalanceService {
	public List<BalByUser> accountBalsByUser(int userId) throws Exception;
	public List<AvgBalByAges> accountAvgBalByAges() throws Exception;
	public Integer totalBalByYears(String year) throws Exception;
	public List<UserAccount> balByTerm(String strDt, String endDt) throws Exception;
}
