package com.ihy.store.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ihy.store.model.Account;
import com.ihy.store.repository.AccountRepository;
import com.ihy.store.service.AccountService;

@Service(value = "accountServiceImpl")
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountRepository accountRepo;

	@Override
	public Account add(Account account) throws Exception {
		return accountRepo.save(account);
	}

	@Override
	public List<Account> getAll() throws Exception {
		return accountRepo.findAll();
	}
}
