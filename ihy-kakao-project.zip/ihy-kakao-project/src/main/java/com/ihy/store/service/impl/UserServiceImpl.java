package com.ihy.store.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ihy.store.model.User;
import com.ihy.store.repository.UserRepository;
import com.ihy.store.service.UserService;

@Service(value = "userServiceImpl")
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepo;
	
	@Override
	public User add(User user) throws Exception {
		return userRepo.save(user);
	}

	@Override
	public List<User> getAll() throws Exception {
		return userRepo.findAll();
	}

}
