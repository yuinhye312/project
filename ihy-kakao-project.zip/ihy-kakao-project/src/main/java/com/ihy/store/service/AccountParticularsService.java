package com.ihy.store.service;

import java.util.List;

import com.ihy.store.model.AccountParticulars;

public interface AccountParticularsService {
	public AccountParticulars add(AccountParticulars acctPtcl) throws Exception;
	public List<AccountParticulars> getAll() throws Exception;
}
