package com.ihy.store.model.balance;

import java.math.BigInteger;

public class UserAccount {
	private int userId;
	private String name;
	private BigInteger balance;
	
	public int getUserId() {
		return userId;
	}
	
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public BigInteger getBalance() {
		return balance;
	}
	
	public void setBalance(BigInteger balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "UserAccount [userId=" + userId + ", name=" + name + ", balance=" + balance
				+ "]";
	}
	
}
