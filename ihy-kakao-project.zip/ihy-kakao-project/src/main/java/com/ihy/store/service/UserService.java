package com.ihy.store.service;

import java.util.List;

import com.ihy.store.model.User;

public interface UserService {
	public User add(User user) throws Exception;
	public List<User> getAll() throws Exception;
}
