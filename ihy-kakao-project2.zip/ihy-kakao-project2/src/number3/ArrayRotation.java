package number3;
import java.util.Scanner;

public class ArrayRotation {

	static String deilemeter = ",";
	static String turnToRightCmd = "R";
	static String turnToLeftCmd = "L";
	static String twistCmd = "T";
	
	static int widthCnt; 
	static int heightCnt;
	static String[][] arrays;
	static String[][] tmpArrays;
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		widthCnt = sc.nextInt(); 
		heightCnt = sc.nextInt(); 
		arrays = new String[widthCnt][heightCnt]; // The Array
		
		String arrayElmts = sc.next();
		String[] tmpArr = arrayElmts.split(deilemeter);

		// Fill the array.	
		int arraysCnt = 0;
		for (int i = 0; i < widthCnt; i++) {
			for (int j = 0; j < heightCnt; j++) {
				arrays[i][j] = tmpArr[arraysCnt];
				arraysCnt++;
			}
		}
		
		// Execution commands.
		String command = sc.next();
		String[] cmds = command.split(deilemeter);
		
		for (String cmd : cmds) {
			if (cmd.equals(turnToLeftCmd)) {
				turnToLeft();
			} else if (cmd.equals(turnToRightCmd)) {
				turnToRight();
			} else if (cmd.equals(twistCmd)) {
				twist();
			}
		}
		
		// Print the result.
		for (int i = 0; i < widthCnt; i++) {
			for (int j = 0; j < heightCnt; j++) {
				System.out.print(arrays[i][j] + " ");
			}
			System.out.println();
		}
	}
	

	public static void twist() {
		tmpArrays = new String[widthCnt][heightCnt];
		
		for (int i = 0; i < widthCnt; i++) {
			for (int j = 0; j < heightCnt; j++) {
				tmpArrays[i][heightCnt - j - 1] = arrays[i][j];
			}
		}
		
		// Return the result.
		arrays = tmpArrays;
	}
	
	public static void turnToRight() {
		tmpArrays = new String[heightCnt][widthCnt];
		
		int r = widthCnt - 1;
		for (int i = 0; i < widthCnt; i++) {
			for(int j = 0; j < heightCnt; j++) {
				tmpArrays[j][r] = arrays[i][j];
			}
			r--;
		}
		
		// Resizing the Array.
		int temp = widthCnt;
		widthCnt = heightCnt;
		heightCnt = temp;
		
		// Return the result.
		arrays = tmpArrays;
	}
	
	public static void turnToLeft() {
		tmpArrays = new String[heightCnt][widthCnt];
		
		for (int i = 0; i < widthCnt; i++) {
			for (int j = 0; j < heightCnt; j++) {
				tmpArrays[heightCnt - j - 1][i] = arrays[i][j];
			}
		}
		
		// Resizing the Array.
		int temp = widthCnt;
		widthCnt = heightCnt;
		heightCnt = temp;
		
		// Return the result.
		arrays = tmpArrays;
	}
	
}	
