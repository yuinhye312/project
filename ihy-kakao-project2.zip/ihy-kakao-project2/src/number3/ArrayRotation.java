package number3;
import java.util.Scanner;

public class ArrayRotation {

	static String deilemeter = ",";
	static char turnToRightCmd = 'R';
	static char turnToLeftCmd = 'L';
	static char twistCmd = 'T';
	
	static int widthCnt; 
	static int heightCnt;
	static String[][] arrays;
	static String[][] tmpArrays;
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		widthCnt = sc.nextInt(); 
		heightCnt = sc.nextInt(); 
		arrays = new String[widthCnt][heightCnt]; // The Array
		
		String arrayElmts = sc.next();
		String[] tmpArr = arrayElmts.split(deilemeter);

		// Fill the array.	
		int arraysCnt = 0;
		for (int i = 0; i < widthCnt; i++) {
			for (int j = 0; j < heightCnt; j++) {
				arrays[i][j] = tmpArr[arraysCnt];
				arraysCnt++;
			}
		}
		
		// Execution commands.
		String command = sc.next();
		
		for (int i = 0; i < command.length(); i++) {
			if (command.charAt(i) == turnToLeftCmd) {
				turnToLeft();
			} else if (command.charAt(i) == turnToRightCmd) {
				turnToRight();
			} else if (command.charAt(i) == twistCmd) {
				twist();
			}
		}
		
		// Point for result.
		String printPoint = sc.next();
		String[] points = printPoint.split(deilemeter);
		
		int x = Integer.parseInt(points[1]) - 1;
		int y = Integer.parseInt(points[0]) - 1;
		
		// Print the result.
		for (int i = 0; i < widthCnt; i++) {
			for (int j = 0; j < heightCnt; j++) {
				System.out.print(arrays[i][j] + " ");
			}
			System.out.println();
		}
		
		System.out.println(arrays[x][y]);
		sc.close();
	}
	

	public static void twist() {
		tmpArrays = new String[widthCnt][heightCnt];
		
		for (int i = 0; i < widthCnt; i++) {
			for (int j = 0; j < heightCnt; j++) {
				tmpArrays[i][heightCnt - j - 1] = arrays[i][j];
			}
		}
		
		// Return the result.
		arrays = tmpArrays;
	}
	
	public static void turnToRight() {
		tmpArrays = new String[heightCnt][widthCnt];
		
		int r = widthCnt - 1;
		for (int i = 0; i < widthCnt; i++) {
			for(int j = 0; j < heightCnt; j++) {
				tmpArrays[j][r] = arrays[i][j];
			}
			r--;
		}
		
		// Resizing the Array.
		int temp = widthCnt;
		widthCnt = heightCnt;
		heightCnt = temp;
		
		// Return the result.
		arrays = tmpArrays;
	}
	
	public static void turnToLeft() {
		tmpArrays = new String[heightCnt][widthCnt];
		
		for (int i = 0; i < widthCnt; i++) {
			for (int j = 0; j < heightCnt; j++) {
				tmpArrays[heightCnt - j - 1][i] = arrays[i][j];
			}
		}
		
		// Resizing the Array.
		int temp = widthCnt;
		widthCnt = heightCnt;
		heightCnt = temp;
		
		// Return the result.
		arrays = tmpArrays;
	}
	
}	
