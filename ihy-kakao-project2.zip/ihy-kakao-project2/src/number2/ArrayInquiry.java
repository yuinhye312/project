package number2;
import java.util.Scanner;

public class ArrayInquiry {

	public static void main(String[] args) {

		String arrDelm = ",";
		
		Scanner sc = new Scanner(System.in);
		
		int widthCnt = sc.nextInt();
		int heightCnt = sc.nextInt();
		
		String arrayElmts = sc.next();
		String[] tmpArr = arrayElmts.split(arrDelm);
		String[][] arrays = new String[widthCnt][heightCnt];
		
		// 가로: 4, 세로: 3
		// 1,2,3,4,5,6,7,8,9,10,11,12
		// 1(0,0)  2(0,1)  3(0,2)  4(0,3)
		// 5(1,0)  6(1,1)  7(1,2)  8(1,3)
		// 9(2,0) 10(2,1) 11(2,2) 12(2,3)
		
		// fill the array
		int arraysCnt = 0;
		for (int i = 0; i < widthCnt; i++) {
			for (int j = 0; j < heightCnt; j++) {
				arrays[i][j] = tmpArr[arraysCnt];
				arraysCnt++;
			}
		}
		
		printOrigin(widthCnt, heightCnt, arrays);
		//printDiagonallyZigzag(widthCnt, heightCnt, arrays);
		
//		

		
	}
	
	public static void printOrigin(int width, int height, String[][] arr) {
		for (int i = 0; i < height; i++) {
			for (int j = 0; j < width; j++) {
				System.out.print(arr[i][j]);
			}
			System.out.println();
		}
	}

	public static void printDiagonallyZigzag(int width, int height, String[][] arr) {
		// (0,0) 0 >
		// (0,1) 1 > (1,0) 1 > 
		// (2,0) 2 > (1,1) 2 > (0,2) 2
		// (0,3) 3 > (1,2) 3 > (2,1) 3
		// (2,2) 4 > (1,3) 4
		// (2,3) 5
		
		// 지그재그 횟수: 가로열 + 세로열 - 1
		
		// 우상향 
		
	}
}
