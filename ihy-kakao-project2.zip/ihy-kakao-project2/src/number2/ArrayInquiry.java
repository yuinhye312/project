package number2;

import java.util.Scanner;

public class ArrayInquiry {
	
	static String deilemeter = ",";
	
	public static void main(String[] args) { 
		
		Scanner sc = new Scanner(System.in); 
		int n = sc.nextInt(); 
		
		String arrayElmts = sc.next();
		String[] tmpArr = arrayElmts.split(deilemeter);
		
		sc.close();
		
		int[][] array = new int[n][n]; 
		
		// fill the array
		int arraysCnt = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				array[i][j] = Integer.parseInt(tmpArr[arraysCnt]);
				arraysCnt++;
			}
		}	
		
		int count = 1; 
		
		// Start Point.
		int currentX = 0; 
		int currentY = 0; 
		
		array[currentX][currentY] = count++; 

		while(count <= n * n) {	
			
			// To the diagonal left bottom.
			if(currentY + 1 < n) { 
				currentY++; 
			} else { 
				currentX++; 
			} 
			
			array[currentX][currentY] = count++; 
			
			while(currentY - 1 > -1 && currentX + 1 < n) {
				array[++currentX][--currentY] = count++; 
			} 
			
		
			// To the diagonal top right.
			if(currentX + 1 < n) { 
				currentX++; 
			}
			else { 
				currentY++; 
			} 
			array[currentX][currentY] = count++; 

			while(currentX - 1 > -1 && currentY + 1 < n) { 
				array[--currentX][++currentY] = count++; 
			} 
			
		}
		
		// Print the result.
		for(int[] xx : array) { 
			for(int nn : xx) { 
				System.out.printf("%d ", nn); 
			} System.out.println(); 
		}
		
	}
	
}
