package number1;
import java.util.Scanner;

public class TimeInterval {
	
	public static void main(String[] args) {
		
		String deleimeter = ":";
		int oneDayOurs = 24;
		
		Scanner sc = new Scanner(System.in);
		
		String startTm = sc.next();
		String endTm = sc.next();
		
		String[] starts = startTm.split(deleimeter);
		String[] ends = endTm.split(deleimeter);
		
		int strOur = Integer.parseInt(starts[0]);
		int endOur = Integer.parseInt(ends[0]);
		
		if (strOur > endOur) {
			endOur = oneDayOurs - endOur;
		}
		
		int strOurToMin = strOur * 60;
		int endOurToMin = endOur * 60;
		
		int strMin = Integer.parseInt(starts[1]);
		int endMin = Integer.parseInt(ends[1]);
		
		int timeInterval = (endOurToMin + endMin) - (strOurToMin + strMin);
		
		System.out.println("Time Interval: " + timeInterval + " min.");

	}
	
}
