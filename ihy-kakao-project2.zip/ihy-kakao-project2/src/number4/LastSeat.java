package number4;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class LastSeat {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int peopleNum = sc.nextInt();
		int pass = sc.nextInt();
		
		List<Integer> circle = new ArrayList<Integer>();
		for (int i = 1; i <= peopleNum; i++) {
			circle.add(i);
		}
		
//		for (Iterator<String> iter = fruits.iterator(); iter.hasNext(); ) {
//			  System.out.println(iter.next());
//			}

		// 2
		// 1, 2, 3, 4, 5 : idx 1 (pass - 1)     : 1
		// 1, 0, 3, 4, 5 : idx 3 (pass - 1) + 2 : 3
		// 1, 0, 3, 0, 5 : idx 0 (pass - 1) + 2 : 5  >= circle.size()
		// 0, 0, 3, 0, 5 : idx 4 (pass - 1) + 2 : 7
		// 0, 0, 3, 0, 0 : 
		
		
		// 3
		// 1, 2, 3, 4, 5, 6, 7: 
		// 1, 2, 0, 4, 5, 6, 7: idx 2 (pass - 1)     : 2
		// 1, 2, 0, 4, 5, 0, 7: idx 5 (pass - 1) + 3 : 5
		// 1, 0, 0, 4, 5, 0, 7: idx 1 (pass - 1) + 3 : 8  (8-7)
		// 1, 0, 0, 4, 5, 0, 0: idx 6 (pass - 1) + 3 : 11 (11-7)
		

		int cnt = 0;
		int removeIdx = 0;	
		
		while (cnt < circle.size() - 1) {

//			if (cnt != 0) {
//				removeIdx = 
//			}
						
			if (cnt == 0) {
				removeIdx = pass - 1;
			} else {
				removeIdx = removeIdx + pass;
				if (removeIdx >= circle.size()) {
					int tmp = removeIdx - circle.size();
					
					
				}
			}
			
			circle.set(removeIdx, 0);
			
			cnt ++;
			System.out.print("횟수: " + cnt + " ");
			
			for (int i = 0; i < circle.size(); i++) {
				System.out.print(circle.get(i));
			}
			System.out.println();
		}
		
		
	}

	

}
